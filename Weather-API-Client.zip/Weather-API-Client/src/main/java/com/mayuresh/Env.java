package com.mayuresh;

public class Env {

	public static String serviceHost;

	static {
		serviceHost = System.getenv("T_SERVICE_HOST");
	}
}
